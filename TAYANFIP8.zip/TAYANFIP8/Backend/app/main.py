from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from jose import jwt, JWTError
from typing import List
from .schemas import HelpRequestItem
from .schemas import HelpRequestDetail
from .schemas import UpdateRequestStatus
from .schemas import VolunteerApplyResponse
from typing import List
from .schemas import OpenRequestItem
from datetime import datetime, timezone
from .schemas import AcceptRequestResponse
from .schemas import VolunteerMyItem, VolunteerUpdateStatus, VolunteerRequestDetail
from .schemas import CreateReview, VolunteerRating
from sqlalchemy.orm import Session, aliased
from fastapi import Query
from .schemas import ReviewFeedItem, VolunteerReviewItem, ReviewsStats, LocationIn
from sqlalchemy import func


from .db import Base, engine, get_db
from .models import User, HelpRequest
from .schemas import (RegisterRequest, LoginRequest, TokenResponse, MeResponse, CreateHelpRequest, HelpRequestResponse,)
from .security import (
    hash_password,
    verify_password,
    create_token,
    SECRET_KEY,
    ALGORITHM,
)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Tayan API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5500",
        "http://localhost:5500",
        "http://127.0.0.1:8000",
        "http://localhost:8000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


bearer = HTTPBearer()

def get_current_user(db: Session, token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        uid = payload.get("sub")
        if not uid:
            return None
        return db.query(User).filter(User.id == int(uid)).first()
    except JWTError:
        return None

def require_role(u, role: str):
    if not u or getattr(u, "role", None) != role:
        raise HTTPException(403, "Forbidden")
    

def volunteer_only(
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    u = get_current_user(db, creds.credentials)
    if not u:
        raise HTTPException(401, "Unauthorized")
    require_role(u, "volunteer")
    return u


@app.get("/")
def root():
    return {"status": "ok"}

@app.post("/auth/register", response_model=TokenResponse)
def register(data: RegisterRequest, db: Session = Depends(get_db)):
    if db.query(User).filter(User.phone == data.phone).first():
        raise HTTPException(400, "Phone already registered")

    role = data.role.strip().lower()
    if role not in ("user", "volunteer"):
        raise HTTPException(400, "role must be user or volunteer")

    u = User(
        name=data.name,
        email=data.email,
        phone=data.phone,
        password_hash=hash_password(data.password),
        role=role,
    )
    db.add(u)
    db.commit()
    db.refresh(u)

    return {
        "access_token": create_token(u.id),
        "token_type": "bearer"
    }


@app.post("/auth/login", response_model=TokenResponse)
def login(data: LoginRequest, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.phone == data.phone).first()
    if not u or not verify_password(data.password, u.password_hash):
        raise HTTPException(400, "Invalid credentials")

    return {"access_token": create_token(u.id), "token_type": "bearer"}

@app.get("/auth/me", response_model=MeResponse)
def me(
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    return {"id": u.id, "name": u.name, "email": u.email, "phone": u.phone, "role": u.role}


@app.post("/requests", response_model=HelpRequestResponse)
def create_request(
    data: CreateHelpRequest,
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    if data.kind not in ("sos", "symptom"):
        raise HTTPException(400, "kind must be sos or symptom")

    r = HelpRequest(
        user_id=u.id,
        kind=data.kind,
        symptoms=data.symptoms,
        comments=data.comments,
        status="new",
        lat=data.lat,
        lng=data.lng,
        address=data.address,
    )
    db.add(r)
    db.commit()
    db.refresh(r)

    return {"id": r.id, "status": r.status}

@app.get("/requests/my", response_model=List[HelpRequestItem])
def my_requests(
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    items = (
        db.query(HelpRequest)
        .filter(HelpRequest.user_id == u.id)
        .order_by(HelpRequest.id.desc())
        .all()
    )
    return items

@app.get("/requests/active", response_model=HelpRequestDetail | None)
def user_active_request(
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    u = get_current_user(db, creds.credentials)
    if not u:
        raise HTTPException(401, "Unauthorized")

    r = (
        db.query(HelpRequest)
        .filter(
            HelpRequest.user_id == u.id,
            HelpRequest.status.in_(["new", "accepted", "in_progress"])
        )
        .order_by(HelpRequest.id.desc())
        .first()
    )

    if not r:
        return None

    return r




@app.get("/requests/open", response_model=List[OpenRequestItem])
def open_requests(
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    require_role(u, "volunteer")

    items = (
        db.query(HelpRequest)
        .filter(HelpRequest.status == "new")
        .order_by(HelpRequest.id.desc())
        .all()
    )
    return items


@app.get("/requests/{request_id}", response_model=HelpRequestDetail)
def get_request(
    request_id: int,
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    r = db.query(HelpRequest).filter(HelpRequest.id == request_id).first()
    if not r or r.user_id != u.id:
        raise HTTPException(404, "Not found")

    volunteer_name = None
    volunteer_phone = None

    if r.accepted_by:
        v = db.query(User).filter(User.id == r.accepted_by).first()
        if v:
            volunteer_name = v.name
            volunteer_phone = v.phone
    
    reaction_minutes = None
    if r.accepted_at:
        delta = r.accepted_at - r.created_at
        reaction_minutes = max(0, int(delta.total_seconds() // 60))

    

    return {
        "id": r.id,
        "kind": r.kind,
        "status": r.status,
        "created_at": r.created_at,
        "symptoms": r.symptoms,
        "comments": r.comments,
        "accepted_by": r.accepted_by,
        "accepted_at": r.accepted_at,
        "volunteer_name": volunteer_name,
        "volunteer_phone": volunteer_phone,
        "volunteer_lat": r.volunteer_lat,
        "volunteer_lng": r.volunteer_lng,
        "address": r.address,
        "reaction_minutes": reaction_minutes,
        "in_progress_at": r.in_progress_at,
        "completed_at": r.completed_at,
        "canceled_at": r.canceled_at,
        "rating": r.rating,
        "review_text": r.review_text,
        "reviewed_at": r.reviewed_at
    }



@app.patch("/requests/{request_id}/status", response_model=HelpRequestDetail)
def update_status(
    request_id: int,
    data: UpdateRequestStatus,
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    allowed = {"canceled"}
    if data.status not in allowed:
        raise HTTPException(400, "status must be canceled or completed")

    r = db.query(HelpRequest).filter(HelpRequest.id == request_id).first()
    if not r or r.user_id != u.id:
        raise HTTPException(404, "Not found")

    if r.status != "new":
        raise HTTPException(400, "Request already handled by volunteer")
    
    now = datetime.now(timezone.utc)

    if data.status == "completed" and r.completed_at is None:
        r.completed_at = now

    if data.status == "canceled" and r.canceled_at is None:
        r.canceled_at = now

    r.status = data.status
    db.commit()
    db.refresh(r)
    return r

@app.post("/requests/{request_id}/review", response_model=HelpRequestDetail)
def leave_review(
    request_id: int,
    data: CreateReview,
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    r = db.query(HelpRequest).filter(HelpRequest.id == request_id).first()
    if not r or r.user_id != u.id:
        raise HTTPException(404, "Not found")
    print(
        "REVIEW DEBUG:",
        "id=", r.id,
        "status=", r.status,
        "accepted_by=", r.accepted_by,
        "rating=", r.rating,
        "completed_at=", r.completed_at
    )

    if r.status != "completed":
        raise HTTPException(400, "You can review only completed requests")

    if not r.accepted_by:
        raise HTTPException(400, "No volunteer assigned")

    if data.rating < 1 or data.rating > 5:
        raise HTTPException(400, "rating must be 1..5")

    if r.rating is not None:
        raise HTTPException(400, "Review already submitted")

    r.rating = data.rating
    r.review_text = (data.review_text or "").strip() or None
    r.reviewed_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(r)
    return r


@app.post("/volunteer/apply", response_model=VolunteerApplyResponse)
def volunteer_apply(
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    u.role = "volunteer"
    db.commit()
    return {"ok": True}

@app.post("/requests/{request_id}/accept", response_model=AcceptRequestResponse)
def accept_request(
    request_id: int,
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    require_role(u, "volunteer")
    active = (
        db.query(HelpRequest)
        .filter(
            HelpRequest.accepted_by == u.id,
            HelpRequest.status.in_(["accepted", "in_progress"])
        )
        .first()
    )

    if active:
        raise HTTPException(400, "You already have an active request")

    r = db.query(HelpRequest).filter(HelpRequest.id == request_id).first()
    if not r:
        raise HTTPException(404, "Not found")

    if r.status != "new":
        raise HTTPException(400, "Request is not new")

    r.status = "accepted"
    r.accepted_by = u.id
    r.accepted_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(r)
    return {"id": r.id, "status": r.status, "accepted_by": r.accepted_by}

@app.get("/volunteer/my", response_model=List[VolunteerMyItem])
def volunteer_my(
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    require_role(u, "volunteer")

    items = (
        db.query(HelpRequest)
        .filter(HelpRequest.accepted_by == u.id)
        .order_by(HelpRequest.id.desc())
        .all()
    )
    return items


@app.get("/volunteer/active", response_model=VolunteerRequestDetail | None)
def volunteer_active(
    u: User = Depends(volunteer_only),
    db: Session = Depends(get_db),
):
    r = (
        db.query(HelpRequest)
        .filter(
            HelpRequest.accepted_by == u.id,
            HelpRequest.status.in_(["accepted", "in_progress"])
        )
        .order_by(HelpRequest.id.desc())
        .first()
    )

    if not r:
        return None

    owner = db.query(User).filter(User.id == r.user_id).first()

    return {
        "id": r.id,
        "user_id": r.user_id,
        "kind": r.kind,
        "status": r.status,
        "created_at": r.created_at,
        "symptoms": r.symptoms,
        "comments": r.comments,
        "accepted_by": r.accepted_by,
        "accepted_at": r.accepted_at,
        "in_progress_at": r.in_progress_at,
        "completed_at": r.completed_at,
        "canceled_at": r.canceled_at,
        "reaction_minutes": None,
        "lat": r.lat,
        "lng": r.lng,
        "address": r.address,
        "user_phone": owner.phone if owner else None,
        "user_name": owner.name if owner else None,
    }



@app.patch("/volunteer/requests/{request_id}/location")
def update_vol_location(
    request_id: int,
    payload: LocationIn,
    u: User = Depends(volunteer_only),
    db: Session = Depends(get_db),
):
    r = db.query(HelpRequest).filter(HelpRequest.id == request_id).first()
    if not r:
        raise HTTPException(404, "Not found")

    if r.accepted_by != u.id:
        raise HTTPException(403, "Forbidden")

    r.volunteer_lat = payload.volunteer_lat
    r.volunteer_lng = payload.volunteer_lng

    db.commit()
    return {"ok": True}

@app.get("/requests/{request_id}/track", response_model=HelpRequestDetail)
def track_request(
    request_id: int,
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    u = get_current_user(db, creds.credentials)
    if not u:
        raise HTTPException(401, "Unauthorized")

    r = db.query(HelpRequest).filter(HelpRequest.id == request_id).first()
    if not r:
        raise HTTPException(404, "Not found")

    if not (r.user_id == u.id or r.accepted_by == u.id):
        raise HTTPException(403, "Forbidden")

    volunteer_name = None
    volunteer_phone = None
    if r.accepted_by:
        v = db.query(User).filter(User.id == r.accepted_by).first()
        if v:
            volunteer_name = v.name
            volunteer_phone = v.phone

    reaction_minutes = None
    if r.accepted_at:
        delta = r.accepted_at - r.created_at
        reaction_minutes = max(0, int(delta.total_seconds() // 60))

    owner = None
    if r.user_id:
        owner = db.query(User).filter(User.id == r.user_id).first()

    return {
        "id": r.id,
        "kind": r.kind,
        "status": r.status,
        "created_at": r.created_at,
        "symptoms": r.symptoms,
        "comments": r.comments,
        "accepted_by": r.accepted_by,
        "accepted_at": r.accepted_at,
        "user_name": owner.name if owner else None,
        "user_phone": owner.phone if owner else None,
        "volunteer_name": volunteer_name,
        "volunteer_phone": volunteer_phone,
        "volunteer_lat": r.volunteer_lat,
        "volunteer_lng": r.volunteer_lng,
        "lat": r.lat,
        "lng": r.lng,
        "address": r.address,
        "in_progress_at": r.in_progress_at,
        "completed_at": r.completed_at,
        "canceled_at": r.canceled_at,
        "reaction_minutes": reaction_minutes,
        "rating": r.rating,
        "review_text": r.review_text,
        "reviewed_at": r.reviewed_at,
    }




@app.get("/volunteer/requests/{request_id}", response_model=VolunteerRequestDetail)
def volunteer_request_detail(
    request_id: int,
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")
    
    require_role(u, "volunteer")

    r = db.query(HelpRequest).filter(HelpRequest.id == request_id).first()
    if not r:
        raise HTTPException(404, "Not found")

    if r.accepted_by != u.id:
        raise HTTPException(403, "Forbidden")
    
    owner = db.query(User).filter(User.id == r.user_id).first()

    return {
        "id": r.id,
        "user_id": r.user_id,
        "kind": r.kind,
        "status": r.status,
        "created_at": r.created_at,
        "symptoms": r.symptoms,
        "comments": r.comments,
        "accepted_by": r.accepted_by,
        "accepted_at": r.accepted_at,
        "in_progress_at": r.in_progress_at,
        "completed_at": r.completed_at,
        "canceled_at": r.canceled_at,
        "reaction_minutes": None,
        "lat": r.lat,
        "lng": r.lng,
        "address": r.address,
        "user_phone": owner.phone if owner else None,
        "user_name": owner.name if owner else None,
    }
    



@app.patch("/volunteer/requests/{request_id}/status", response_model=VolunteerRequestDetail)
def volunteer_update_status(
    request_id: int,
    data: VolunteerUpdateStatus,
    creds: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    token = creds.credentials
    u = get_current_user(db, token)
    if not u:
        raise HTTPException(401, "Unauthorized")

    require_role(u, "volunteer")

    r = db.query(HelpRequest).filter(HelpRequest.id == request_id).first()
    if not r:
        raise HTTPException(404, "Not found")

    if r.accepted_by != u.id:
        raise HTTPException(403, "Forbidden")

    allowed = {"accepted", "in_progress", "completed", "canceled"}

    if data.status not in allowed:
        raise HTTPException(400, "status must be accepted, in_progress, completed or canceled")

    if r.status in ("completed", "canceled"):
        raise HTTPException(400, "Request already closed")

    if r.status == "new":
        raise HTTPException(400, "Request must be accepted first")

    if r.status == "accepted" and data.status not in ("in_progress", "canceled"):
        raise HTTPException(400, "From accepted you can only go to in_progress or canceled")

    if r.status == "in_progress" and data.status not in ("completed", "canceled"):
        raise HTTPException(400, "From in_progress you can only go to completed or canceled")
    
    now = datetime.now(timezone.utc)

    if data.status == "in_progress" and r.in_progress_at is None:
        r.in_progress_at = now

    if data.status == "completed" and r.completed_at is None:
        r.completed_at = now

    if data.status == "canceled" and r.canceled_at is None:
        r.canceled_at = now


    r.status = data.status
    db.commit()
    db.refresh(r)
    return r

@app.get("/volunteer/{volunteer_id}/rating", response_model=VolunteerRating)
def volunteer_rating(volunteer_id: int, db: Session = Depends(get_db)):
    avg_rating = (
        db.query(func.avg(HelpRequest.rating))
        .filter(HelpRequest.accepted_by == volunteer_id, HelpRequest.rating.isnot(None))
        .scalar()
    )
    count = (
        db.query(func.count(HelpRequest.rating))
        .filter(HelpRequest.accepted_by == volunteer_id, HelpRequest.rating.isnot(None))
        .scalar()
    )

    return {
        "volunteer_id": volunteer_id,
        "avg_rating": float(avg_rating or 0.0),
        "reviews_count": int(count or 0),
    }


@app.get("/reviews/latest", response_model=List[ReviewFeedItem])
def latest_reviews(
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    V = aliased(User)
    U = aliased(User)

    rows = (
        db.query(
            HelpRequest.id.label("request_id"),
            HelpRequest.rating,
            HelpRequest.review_text,
            HelpRequest.reviewed_at,
            HelpRequest.kind,
            HelpRequest.accepted_by.label("volunteer_id"),
            V.name.label("volunteer_name"),
            HelpRequest.user_id.label("user_id"),
            U.name.label("user_name"),
        )
        .join(V, V.id == HelpRequest.accepted_by)
        .join(U, U.id == HelpRequest.user_id)
        .filter(HelpRequest.rating.isnot(None))
        .order_by(HelpRequest.reviewed_at.desc())
        .limit(limit)
        .all()
    )

    return [
        {
            "request_id": r.request_id,
            "rating": int(r.rating),
            "review_text": r.review_text,
            "reviewed_at": r.reviewed_at,
            "volunteer_id": int(r.volunteer_id),
            "volunteer_name": r.volunteer_name,
            "user_id": int(r.user_id),
            "user_name": r.user_name,
            "kind": r.kind,
        }
        for r in rows
    ]


@app.get("/volunteer/{volunteer_id}/reviews", response_model=List[VolunteerReviewItem])
def volunteer_reviews(
    volunteer_id: int,
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0, le=10000),
    db: Session = Depends(get_db),
):
    U = aliased(User)

    rows = (
        db.query(
            HelpRequest.id.label("request_id"),
            HelpRequest.rating,
            HelpRequest.review_text,
            HelpRequest.reviewed_at,
            HelpRequest.kind,
            HelpRequest.user_id.label("user_id"),
            U.name.label("user_name"),
        )
        .join(U, U.id == HelpRequest.user_id)
        .filter(
            HelpRequest.accepted_by == volunteer_id,
            HelpRequest.rating.isnot(None),
        )
        .order_by(HelpRequest.reviewed_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    return [
        {
            "request_id": r.request_id,
            "rating": int(r.rating),
            "review_text": r.review_text,
            "reviewed_at": r.reviewed_at,
            "user_id": int(r.user_id),
            "user_name": r.user_name,
            "kind": r.kind,
        }
        for r in rows
    ]

@app.get("/reviews/stats", response_model=ReviewsStats)
def reviews_stats(db: Session = Depends(get_db)):
    avg_rating = (
        db.query(func.avg(HelpRequest.rating))
        .filter(HelpRequest.rating.isnot(None))
        .scalar()
    )

    count = (
        db.query(func.count(HelpRequest.rating))
        .filter(HelpRequest.rating.isnot(None))
        .scalar()
    )

    return {
        "avg_rating": float(avg_rating or 0.0),
        "reviews_count": int(count or 0),
    }









