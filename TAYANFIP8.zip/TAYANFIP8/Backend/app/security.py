from datetime import datetime, timedelta, timezone
from jose import jwt
from passlib.context import CryptContext

pwd = CryptContext(schemes=["argon2"], deprecated="auto")

SECRET_KEY = "CHANGE_ME_TO_SOMETHING_LONG"
ALGORITHM = "HS256"
EXPIRE_MIN = 60 * 24 * 7

def hash_password(p: str) -> str:
    return pwd.hash(p)

def verify_password(p: str, h: str) -> bool:
    return pwd.verify(p, h)

def create_token(user_id: int) -> str:
    now = datetime.now(timezone.utc)
    exp = now + timedelta(minutes=EXPIRE_MIN)
    return jwt.encode({"sub": str(user_id), "iat": int(now.timestamp()), "exp": exp}, SECRET_KEY, algorithm=ALGORITHM)
