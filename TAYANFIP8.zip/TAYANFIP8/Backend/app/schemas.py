from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class RegisterRequest(BaseModel):
    name: str
    email: Optional[str] = None
    phone: str
    password: str
    role: str = "user"


class LoginRequest(BaseModel):
    phone: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class MeResponse(BaseModel):
    id: int
    name: str
    email: Optional[str] = None
    phone: str
    role: str


class CreateHelpRequest(BaseModel):
    kind: str
    symptoms: Optional[str] = None
    comments: Optional[str] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    address: Optional[str] = None


class HelpRequestResponse(BaseModel):
    id: int
    status: str


class HelpRequestItem(BaseModel):
    id: int
    kind: str
    status: str
    created_at: datetime
    symptoms: Optional[str] = None
    comments: Optional[str] = None
    accepted_by: Optional[int] = None
    accepted_at: Optional[datetime] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    address: Optional[str] = None
    in_progress_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
    reaction_minutes: Optional[int] = None
    rating: Optional[int] = None
    review_text: Optional[str] = None
    reviewed_at: Optional[datetime] = None



    class Config:
        from_attributes = True


class HelpRequestDetail(BaseModel):
    id: int
    kind: str
    status: str
    created_at: datetime
    symptoms: Optional[str] = None
    comments: Optional[str] = None
    accepted_by: Optional[int] = None
    accepted_at: Optional[datetime] = None
    volunteer_name: Optional[str] = None
    volunteer_phone: Optional[str] = None
    volunteer_lat: Optional[float] = None
    volunteer_lng: Optional[float] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    address: Optional[str] = None
    in_progress_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
    reaction_minutes: Optional[int] = None
    rating: Optional[int] = None
    review_text: Optional[str] = None
    reviewed_at: Optional[datetime] = None



    class Config:
        from_attributes = True


class UpdateRequestStatus(BaseModel):
    status: str


class VolunteerApplyResponse(BaseModel):
    ok: bool = True


class OpenRequestItem(BaseModel):
    id: int
    kind: str
    status: str
    created_at: datetime
    symptoms: Optional[str] = None
    comments: Optional[str] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    address: Optional[str] = None

    class Config:
        from_attributes = True


class AcceptRequestResponse(BaseModel):
    id: int
    status: str
    accepted_by: Optional[int] = None


class VolunteerMyItem(BaseModel):
    id: int
    kind: str
    status: str
    created_at: datetime
    symptoms: Optional[str] = None
    comments: Optional[str] = None
    accepted_at: Optional[datetime] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    address: Optional[str] = None
    in_progress_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    canceled_at: Optional[datetime] = None


    class Config:
        from_attributes = True


class VolunteerUpdateStatus(BaseModel):
    status: str


class VolunteerRequestDetail(BaseModel):
    id: int
    user_id: int
    kind: str
    status: str
    created_at: datetime
    symptoms: Optional[str] = None
    comments: Optional[str] = None
    accepted_by: Optional[int] = None
    accepted_at: Optional[datetime] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    address: Optional[str] = None
    in_progress_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
    user_name: Optional[str] = None
    user_phone: Optional[str] = None


    class Config:
        from_attributes = True

class CreateReview(BaseModel):
    rating: int
    review_text: Optional[str] = None

class VolunteerRating(BaseModel):
    volunteer_id: int
    avg_rating: float
    reviews_count: int


class ReviewFeedItem(BaseModel):
    request_id: int
    rating: int
    review_text: Optional[str] = None
    reviewed_at: datetime

    volunteer_id: int
    volunteer_name: Optional[str] = None

    user_id: int
    user_name: Optional[str] = None

    kind: str

class VolunteerReviewItem(BaseModel):
    request_id: int
    rating: int
    review_text: Optional[str] = None
    reviewed_at: datetime
    user_id: int
    user_name: Optional[str] = None
    kind: str

    
class ReviewsStats(BaseModel):
    avg_rating: float
    reviews_count: int

class LocationIn(BaseModel):
    volunteer_lat: float
    volunteer_lng: float




